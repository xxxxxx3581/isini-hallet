-- ============================================================================
-- İŞİNİ HALLET — V0.1 DATABASE CORE
-- Tek parça migration: extensions, enums, tables, indexes, triggers, RLS,
-- storage buckets + storage policies.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0. EXTENSIONS
-- ----------------------------------------------------------------------------
create extension if not exists "pgcrypto";
-- gen_random_uuid() için. Supabase projelerinde genelde zaten aktiftir.

-- ----------------------------------------------------------------------------
-- 1. ENUMS
-- ----------------------------------------------------------------------------

create type case_type as enum (
  'property_sale'
);

create type case_status as enum (
  'draft',
  'collecting_info',
  'documents_pending',
  'calculating',
  'ready',
  'completed',
  'archived'
);

create type answer_source as enum (
  'user_input',
  'document_extraction',
  'inferred',
  'system_verified'
);

create type requirement_type as enum (
  'document',
  'action',
  'payment',
  'tax_calculation',
  'information',
  'warning'
);

create type requirement_status as enum (
  'pending',
  'needs_verification',
  'satisfied',
  'not_applicable',
  'blocked'
);

create type document_type as enum (
  'tapu',
  'kimlik',
  'dask_policesi',
  'vekaletname',
  'diger'
);

create type document_processing_status as enum (
  'pending',
  'processing',
  'processed',
  'failed'
);

create type verification_status as enum (
  'unverified',
  'user_confirmed',
  'user_corrected'
);

create type calculation_type as enum (
  'tapu_harci',
  'deger_artis_kazanci'
);

create type calculation_result_category as enum (
  'not_applicable',
  'calculation_required',
  'potential_tax'
);

create type generated_document_status as enum (
  'draft'
);

create type confidence_level as enum (
  'high',
  'medium',
  'low',
  'unresolved'
);

create type official_source_authority as enum (
  'kanun',
  'yonetmelik',
  'teblig',
  'tkgm',
  'gib',
  'edevlet',
  'diger'
);

create type case_event_type as enum (
  'status_change',
  'document_uploaded',
  'requirement_satisfied',
  'calculation_run',
  'document_generated'
);

-- ----------------------------------------------------------------------------
-- 2. TABLES
-- ----------------------------------------------------------------------------

-- profiles ---------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  phone text,
  phone_verified boolean not null default false,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- cases --------------------------------------------------------------------
create table public.cases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  case_type case_type not null default 'property_sale',
  status case_status not null default 'draft',
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index cases_user_id_idx on public.cases (user_id);
create index cases_user_id_status_idx on public.cases (user_id, status);

-- case_answers ---------------------------------------------------------------
create table public.case_answers (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  question_key text not null,
  answer_value jsonb not null,
  source answer_source not null default 'user_input',
  confidence numeric(3, 2) check (confidence is null or (confidence >= 0 and confidence <= 1)),
  verified_at timestamptz,
  verified_by uuid references public.profiles (id),
  answered_at timestamptz not null default now(),
  unique (case_id, question_key)
);

create index case_answers_case_id_idx on public.case_answers (case_id);

-- requirements (sistem-geneli kural kütüphanesi, case_id YOK) -------------
create table public.requirements (
  id uuid primary key default gen_random_uuid(),
  key text not null,
  name text not null,
  description text,
  case_type case_type not null,
  condition_expression jsonb not null,
  requirement_type requirement_type not null,
  required boolean not null default true,
  action_template text,
  source text,
  source_url text,
  effective_date date,
  confidence confidence_level not null default 'medium',
  version integer not null default 1,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (key, version)
);

create index requirements_case_type_active_idx on public.requirements (case_type, is_active);

-- case_requirements ------------------------------------------------------
create table public.case_requirements (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  -- ON DELETE RESTRICT (varsayılan NO ACTION): bir requirement versiyonu
  -- herhangi bir case_requirements satırından referans alınıyorsa silinemez.
  -- Requirement kütüphanesinde "silme" değil is_active=false + yeni version
  -- kullanılır; bu FK bunu veritabanı seviyesinde de garanti eder.
  requirement_id uuid not null references public.requirements (id),
  applies boolean not null,
  status requirement_status not null default 'pending',
  evaluation_snapshot jsonb,
  evaluated_at timestamptz not null default now(),
  unique (case_id, requirement_id)
);

create index case_requirements_case_id_idx on public.case_requirements (case_id);
create index case_requirements_case_id_status_idx on public.case_requirements (case_id, status);

-- documents ----------------------------------------------------------------
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  uploaded_by uuid not null references public.profiles (id),
  storage_path text not null,
  document_type document_type not null default 'diger',
  original_filename text,
  mime_type text,
  processing_status document_processing_status not null default 'pending',
  uploaded_at timestamptz not null default now()
);

create index documents_case_id_idx on public.documents (case_id);
create index documents_case_id_status_idx on public.documents (case_id, processing_status);

-- document_extractions -------------------------------------------------------
create table public.document_extractions (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.documents (id) on delete cascade,
  field_key text not null,
  field_value jsonb not null,
  confidence numeric(3, 2) check (confidence is null or (confidence >= 0 and confidence <= 1)),
  verification_status verification_status not null default 'unverified',
  extracted_at timestamptz not null default now()
);

create index document_extractions_document_id_idx on public.document_extractions (document_id);

-- calculations ---------------------------------------------------------------
create table public.calculations (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  calculation_type calculation_type not null,
  input_snapshot jsonb not null,
  result jsonb not null,
  result_category calculation_result_category not null,
  rule_version text,
  disclaimer_shown boolean not null default true,
  calculated_at timestamptz not null default now()
);

create index calculations_case_id_idx on public.calculations (case_id);
create index calculations_case_id_type_idx on public.calculations (case_id, calculation_type);

-- official_sources -----------------------------------------------------------
create table public.official_sources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  authority official_source_authority not null,
  url text,
  effective_date date,
  last_verified_at timestamptz,
  notes text,
  created_at timestamptz not null default now()
);

-- generated_documents ---------------------------------------------------------
create table public.generated_documents (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  document_template_key text not null,
  content text,
  storage_path text,
  status generated_document_status not null default 'draft',
  disclaimer_text text not null,
  generated_at timestamptz not null default now(),
  downloaded_at timestamptz,
  check (content is not null or storage_path is not null)
);

create index generated_documents_case_id_idx on public.generated_documents (case_id);

-- case_events ------------------------------------------------------------
create table public.case_events (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references public.cases (id) on delete cascade,
  event_type case_event_type not null,
  payload jsonb,
  created_at timestamptz not null default now()
);

create index case_events_case_id_created_at_idx on public.case_events (case_id, created_at);

-- notifications ----------------------------------------------------------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  case_id uuid references public.cases (id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index notifications_user_id_is_read_idx on public.notifications (user_id, is_read);

-- audit_logs ---------------------------------------------------------------
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles (id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  before_state jsonb,
  after_state jsonb,
  created_at timestamptz not null default now()
);

create index audit_logs_entity_idx on public.audit_logs (entity_type, entity_id);

-- ----------------------------------------------------------------------------
-- 3. TRIGGERS — updated_at otomatik güncelleme
-- ----------------------------------------------------------------------------

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_updated_at_profiles
  before update on public.profiles
  for each row
  execute function public.set_updated_at();

create trigger set_updated_at_cases
  before update on public.cases
  for each row
  execute function public.set_updated_at();

-- ----------------------------------------------------------------------------
-- 3b. TRIGGER — auth.users -> profiles otomatik satır oluşturma
-- (Supabase Auth ile çalışmak için gerekli standart plumbing; üyelik/abonelik
-- sistemi değildir, yalnızca profiles.id FK'sinin karşılığını garanti eder.)
-- ----------------------------------------------------------------------------

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id)
  values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- ----------------------------------------------------------------------------
-- 4. ROW LEVEL SECURITY
-- ----------------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.cases enable row level security;
alter table public.case_answers enable row level security;
alter table public.requirements enable row level security;
alter table public.case_requirements enable row level security;
alter table public.documents enable row level security;
alter table public.document_extractions enable row level security;
alter table public.calculations enable row level security;
alter table public.official_sources enable row level security;
alter table public.generated_documents enable row level security;
alter table public.case_events enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

-- profiles: sahibi okur/yazar -------------------------------------------
create policy "profiles_select_own"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- insert yok: satır handle_new_user() trigger'ı (security definer) ile açılır.

-- cases: sahibi tam yetki --------------------------------------------------
create policy "cases_select_own"
  on public.cases for select
  to authenticated
  using (user_id = auth.uid());

create policy "cases_insert_own"
  on public.cases for insert
  to authenticated
  with check (user_id = auth.uid());

create policy "cases_update_own"
  on public.cases for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy "cases_delete_own"
  on public.cases for delete
  to authenticated
  using (user_id = auth.uid());

-- case_answers: case sahibi tam yetki (case'e tek seviye join, recursive değil)
create policy "case_answers_select_own"
  on public.case_answers for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = case_answers.case_id
        and c.user_id = auth.uid()
    )
  );

create policy "case_answers_insert_own"
  on public.case_answers for insert
  to authenticated
  with check (
    exists (
      select 1 from public.cases c
      where c.id = case_answers.case_id
        and c.user_id = auth.uid()
    )
  );

create policy "case_answers_update_own"
  on public.case_answers for update
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = case_answers.case_id
        and c.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.cases c
      where c.id = case_answers.case_id
        and c.user_id = auth.uid()
    )
  );

create policy "case_answers_delete_own"
  on public.case_answers for delete
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = case_answers.case_id
        and c.user_id = auth.uid()
    )
  );

-- requirements: herkese (authenticated) salt-okunur, yazma yalnızca service_role
create policy "requirements_select_all_authenticated"
  on public.requirements for select
  to authenticated
  using (true);

-- insert/update/delete policy YOK -> authenticated rolü yazamaz.
-- service_role RLS'i bypass eder (Supabase varsayılanı), admin/backoffice
-- işlemleri service_role key ile yapılmalı.

-- case_requirements: SADECE okuma, sahibi üzerinden; yazma service_role'de
create policy "case_requirements_select_own"
  on public.case_requirements for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = case_requirements.case_id
        and c.user_id = auth.uid()
    )
  );

-- insert/update/delete policy YOK -> yalnızca service_role (Edge Function)
-- requirement engine sonucu yazabilir; kullanıcı sonucu doğrudan değiştiremez.

-- documents: kullanıcı kendi case'ine yükler/okur/siler; durum güncellemesi service_role'de
create policy "documents_select_own"
  on public.documents for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = documents.case_id
        and c.user_id = auth.uid()
    )
  );

create policy "documents_insert_own"
  on public.documents for insert
  to authenticated
  with check (
    uploaded_by = auth.uid()
    and exists (
      select 1 from public.cases c
      where c.id = documents.case_id
        and c.user_id = auth.uid()
    )
  );

create policy "documents_delete_own"
  on public.documents for delete
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = documents.case_id
        and c.user_id = auth.uid()
    )
  );

-- update policy YOK: processing_status gibi alanlar yalnızca service_role
-- (Edge Function) tarafından güncellenir.

-- document_extractions: SADECE okuma, documents -> cases iki seviye join
create policy "document_extractions_select_own"
  on public.document_extractions for select
  to authenticated
  using (
    exists (
      select 1
      from public.documents d
      join public.cases c on c.id = d.case_id
      where d.id = document_extractions.document_id
        and c.user_id = auth.uid()
    )
  );

-- insert/update/delete policy YOK -> yalnızca service_role (AI extraction
-- pipeline) yazabilir. Kural motoru zaten bu tabloyu değil case_answers'ı okur.

-- calculations: SADECE okuma, sahibi üzerinden; yazma service_role'de
create policy "calculations_select_own"
  on public.calculations for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = calculations.case_id
        and c.user_id = auth.uid()
    )
  );

-- insert/update/delete policy YOK -> yalnızca service_role hesaplama yazabilir.

-- official_sources: herkese (authenticated) salt-okunur, yazma service_role'de
create policy "official_sources_select_all_authenticated"
  on public.official_sources for select
  to authenticated
  using (true);

-- insert/update/delete policy YOK -> yalnızca service_role.

-- generated_documents: SADECE okuma, sahibi üzerinden; yazma service_role'de
create policy "generated_documents_select_own"
  on public.generated_documents for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = generated_documents.case_id
        and c.user_id = auth.uid()
    )
  );

-- insert/update/delete policy YOK -> yalnızca service_role taslak üretebilir.

-- case_events: SADECE okuma, sahibi üzerinden; yazma service_role'de
create policy "case_events_select_own"
  on public.case_events for select
  to authenticated
  using (
    exists (
      select 1 from public.cases c
      where c.id = case_events.case_id
        and c.user_id = auth.uid()
    )
  );

-- insert policy YOK -> timeline event'leri yalnızca service_role (Edge
-- Function) tarafından, ilgili işlemle birlikte tutarlı şekilde yazılır.

-- notifications: sahibi okur, yalnızca is_read alanını günceller (uygulama
-- katmanında yalnızca is_read gönderilmeli; RLS kolon bazlı kısıtlama yapmaz)
create policy "notifications_select_own"
  on public.notifications for select
  to authenticated
  using (user_id = auth.uid());

create policy "notifications_update_own"
  on public.notifications for update
  to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- insert policy YOK -> bildirimler yalnızca service_role tarafından oluşturulur.

-- audit_logs: hiçbir authenticated/anon erişimi yok (policy tanımlanmadı,
-- RLS aktif -> service_role dışında tamamen kapalı).

-- ----------------------------------------------------------------------------
-- 5. STORAGE — private bucket'lar ve policy'ler
-- ----------------------------------------------------------------------------

insert into storage.buckets (id, name, public)
values
  ('case-documents', 'case-documents', false),
  ('generated-documents', 'generated-documents', false)
on conflict (id) do nothing;

-- Path convention: {case_id}/{filename} -> ilk klasör segmenti case_id'dir.

-- case-documents: case sahibi kendi klasörüne okuyabilir/yükleyebilir/silebilir
create policy "case_documents_select_own"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'case-documents'
    and exists (
      select 1 from public.cases c
      where c.id::text = (storage.foldername(name))[1]
        and c.user_id = auth.uid()
    )
  );

create policy "case_documents_insert_own"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'case-documents'
    and exists (
      select 1 from public.cases c
      where c.id::text = (storage.foldername(name))[1]
        and c.user_id = auth.uid()
    )
  );

create policy "case_documents_delete_own"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'case-documents'
    and exists (
      select 1 from public.cases c
      where c.id::text = (storage.foldername(name))[1]
        and c.user_id = auth.uid()
    )
  );

-- generated-documents: kullanıcı yalnızca okur; yazma/silme yalnızca service_role
create policy "generated_documents_storage_select_own"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'generated-documents'
    and exists (
      select 1 from public.cases c
      where c.id::text = (storage.foldername(name))[1]
        and c.user_id = auth.uid()
    )
  );

-- insert/update/delete policy YOK -> yalnızca service_role (belge üretim
-- Edge Function'ı) generated-documents bucket'ına yazabilir.

-- ============================================================================
-- SON
-- ============================================================================
