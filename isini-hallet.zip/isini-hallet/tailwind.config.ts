import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: "#F4F5F1",
        ink: "#1D1E1B",
        muted: "#666B63",
        line: "#DEE1D9",
        surface: "#FFFFFF",
        petrol: {
          DEFAULT: "#0E5C53",
          dark: "#093F39",
          light: "#E5EFEC",
        },
        amber: {
          DEFAULT: "#B9812E",
          light: "#F5E9D6",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-manrope)", "sans-serif"],
      },
      borderRadius: {
        card: "20px",
      },
      boxShadow: {
        soft: "0 1px 2px rgba(29, 30, 27, 0.04), 0 8px 24px rgba(29, 30, 27, 0.06)",
      },
    },
  },
  plugins: [],
};

export default config;
