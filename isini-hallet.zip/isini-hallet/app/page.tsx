import { Header } from "@/components/landing/Header";
import { Hero } from "@/components/landing/Hero";
import { Container } from "@/components/ui/Container";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-paper">
      <Header />
      <Hero />
      <footer className="border-t border-line/70 py-6">
        <Container>
          <p className="text-sm text-muted">
            İşini Hallet, resmî işlemleriniz için hazırlık ve takip aracıdır;
            resmî kurumların, avukatın veya mali müşavirin yerine geçmez.
          </p>
        </Container>
      </footer>
    </main>
  );
}
