import { Header } from "@/components/landing/Header";
import { Container } from "@/components/ui/Container";

export default function GirisPage() {
  return (
    <main className="min-h-screen bg-paper">
      <Header />
      <section className="py-16">
        <Container className="max-w-md text-center">
          <h1 className="font-display text-2xl text-ink">Giriş</h1>
          <p className="mt-3 text-sm text-muted">
            Giriş ekranı, Supabase Auth entegrasyonuyla birlikte bir sonraki
            aşamada eklenecek.
          </p>
        </Container>
      </section>
    </main>
  );
}
