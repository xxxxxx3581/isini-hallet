"use client";

import { useState } from "react";
import { Header } from "@/components/landing/Header";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { StepProgress } from "@/components/process/StepProgress";
import { PropertyTypeCard } from "@/components/process/PropertyTypeCard";

type PropertyType = "konut" | "arsa" | "tarla";

const propertyTypes: {
  id: PropertyType;
  icon: string;
  label: string;
  supported: boolean;
}[] = [
  { id: "konut", icon: "🏠", label: "Konut / Bina", supported: true },
  { id: "arsa", icon: "🌳", label: "Arsa", supported: false },
  { id: "tarla", icon: "🌾", label: "Tarla", supported: false },
];

export default function KonutSatisiPage() {
  const [selected, setSelected] = useState<PropertyType | null>(null);

  const selectedType = propertyTypes.find((type) => type.id === selected);
  const showUnsupportedNotice = Boolean(selectedType && !selectedType.supported);

  return (
    <main className="min-h-screen bg-paper">
      <Header />
      <section className="py-10 sm:py-14">
        <Container className="max-w-3xl">
          <h1 className="font-display text-3xl text-ink sm:text-4xl">
            Ev satış işleminizi hazırlayalım.
          </h1>
          <p className="mt-3 max-w-xl text-base leading-relaxed text-muted">
            Size birkaç soru soracağız. Cevaplarınıza göre hangi belgelerin ve
            işlemlerin gerekli olduğunu belirleyeceğiz.
          </p>

          <div className="mt-8">
            <StepProgress currentStep={1} />
          </div>

          <div className="mt-10 rounded-card border border-line bg-surface p-6 shadow-soft sm:p-8">
            <h2 className="font-display text-xl text-ink">
              Satacağınız taşınmaz nedir?
            </h2>

            <div className="mt-5 flex flex-col gap-3 sm:flex-row">
              {propertyTypes.map((type) => (
                <PropertyTypeCard
                  key={type.id}
                  icon={type.icon}
                  label={type.label}
                  supported={type.supported}
                  selected={selected === type.id}
                  onSelect={() => setSelected(type.id)}
                />
              ))}
            </div>

            {showUnsupportedNotice && (
              <p className="mt-4 rounded-lg bg-amber-light px-4 py-3 text-sm text-amber">
                Bu işlem türü henüz MVP kapsamında değil.
              </p>
            )}

            <div className="mt-8 flex justify-end">
              <Button disabled={selected !== "konut"}>Devam Et</Button>
            </div>
          </div>
        </Container>
      </section>
    </main>
  );
}
