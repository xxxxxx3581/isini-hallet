import { Header } from "@/components/landing/Header";
import { Container } from "@/components/ui/Container";
import { ProcessCard } from "@/components/process/ProcessCard";

export default function IslemlerPage() {
  return (
    <main className="min-h-screen bg-paper">
      <Header />
      <section className="py-12 sm:py-16">
        <Container>
          <h1 className="font-display text-3xl text-ink sm:text-4xl">
            Ne yapmak istiyorsunuz?
          </h1>

          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <ProcessCard
              icon="🏠"
              title="Evimi Satacağım"
              description="Tapu, belgeler, harçlar ve gerekli adımları birlikte hazırlayalım."
              href="/islemler/konut-satisi"
            />
            <ProcessCard
              icon="🚗"
              title="Aracımı Satacağım"
              description="Araç satış işlemleriniz için gereken adımları hazırlayın."
              disabled
            />
            <ProcessCard
              icon="📄"
              title="Resmî Başvuru Hazırlayacağım"
              description="Bir kuruma yapacağınız başvuruyu adım adım hazırlayın."
              disabled
            />
            <ProcessCard
              icon="🏠"
              title="Evimi Kiralayacağım"
              description="Kiralama sürecinizdeki belge ve adımları hazırlayın."
              disabled
            />
          </div>
        </Container>
      </section>
    </main>
  );
}
