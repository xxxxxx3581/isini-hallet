const steps = [
  { label: "Bilgiler", state: "done" as const },
  { label: "Belgeler", state: "active" as const },
  { label: "Kontrol", state: "upcoming" as const },
  { label: "Hesaplama", state: "upcoming" as const },
  { label: "İşlem Dosyası", state: "upcoming" as const },
];

export function CaseFilePreview() {
  return (
    <div className="relative w-full max-w-sm">
      {/* folder tab */}
      <div className="ml-6 h-6 w-32 rounded-t-lg bg-surface" />
      <div className="rounded-card rounded-tl-none bg-surface p-6 shadow-soft">
        <div className="flex items-center justify-between border-b border-line pb-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted">
              İşlem Dosyası
            </p>
            <p className="font-display text-lg text-ink">Konut Satışı</p>
          </div>
          <span className="rounded-full bg-amber-light px-3 py-1 text-xs font-semibold text-amber">
            Devam ediyor
          </span>
        </div>

        <ol className="mt-5 space-y-3">
          {steps.map((step, index) => (
            <li key={step.label} className="flex items-center gap-3">
              <span
                className={`flex h-7 w-7 flex-none items-center justify-center rounded-full text-xs font-semibold ${
                  step.state === "done"
                    ? "bg-petrol text-white"
                    : step.state === "active"
                      ? "border-2 border-petrol text-petrol"
                      : "border border-line text-muted"
                }`}
              >
                {step.state === "done" ? "✓" : index + 1}
              </span>
              <span
                className={`text-sm ${
                  step.state === "upcoming"
                    ? "text-muted"
                    : "font-medium text-ink"
                }`}
              >
                {step.label}
              </span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
