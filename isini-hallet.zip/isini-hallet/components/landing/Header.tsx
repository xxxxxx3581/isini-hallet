import Link from "next/link";
import { Container } from "@/components/ui/Container";

export function Header() {
  return (
    <header className="border-b border-line/70">
      <Container className="flex h-16 items-center justify-between sm:h-20">
        <Link
          href="/"
          className="font-display text-lg font-medium tracking-tight text-ink sm:text-xl"
        >
          İşini Hallet
        </Link>
        <Link
          href="/giris"
          className="rounded-full border border-line px-4 py-2 text-sm font-semibold text-ink transition-colors hover:border-petrol hover:text-petrol sm:px-5"
        >
          Giriş Yap
        </Link>
      </Container>
    </header>
  );
}
