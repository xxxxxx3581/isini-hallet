import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { CaseFilePreview } from "@/components/landing/CaseFilePreview";

export function Hero() {
  return (
    <section className="py-14 sm:py-20">
      <Container className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <div>
          <p className="text-sm font-semibold uppercase tracking-wide text-petrol">
            İşini Hallet
          </p>
          <h1 className="mt-4 font-display text-4xl leading-[1.1] text-ink sm:text-5xl">
            Bir işiniz mi var?
          </h1>
          <p className="mt-5 max-w-md text-lg leading-relaxed text-muted">
            Belgelerinizi, gerekli işlemleri ve izlemeniz gereken adımları tek
            yerde hazırlayın.
          </p>

          <div className="mt-8 flex flex-col items-start gap-3 sm:flex-row sm:items-center">
            <Button href="/islemler" variant="primary" className="w-full sm:w-auto">
              İşlemimi Başlat
            </Button>
          </div>
          <p className="mt-4 text-sm text-muted">
            Şimdilik konut satış işlemiyle başlıyoruz.
          </p>
        </div>

        <div className="flex justify-center lg:justify-end">
          <CaseFilePreview />
        </div>
      </Container>
    </section>
  );
}
