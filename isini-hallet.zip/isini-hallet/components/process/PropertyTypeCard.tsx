type PropertyTypeCardProps = {
  icon: string;
  label: string;
  selected: boolean;
  supported: boolean;
  onSelect: () => void;
};

export function PropertyTypeCard({
  icon,
  label,
  selected,
  supported,
  onSelect,
}: PropertyTypeCardProps) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      className={`flex flex-1 flex-col items-center gap-2 rounded-card border px-4 py-6 text-center transition-colors ${
        selected
          ? "border-petrol bg-petrol-light"
          : "border-line bg-surface hover:border-petrol/40"
      }`}
    >
      <span className="text-3xl" aria-hidden="true">
        {icon}
      </span>
      <span className={`text-sm font-semibold ${selected ? "text-petrol-dark" : "text-ink"}`}>
        {label}
      </span>
      {!supported && (
        <span className="text-xs text-muted">MVP kapsamında değil</span>
      )}
    </button>
  );
}
