import { Button } from "@/components/ui/Button";

type ProcessCardProps = {
  icon: string;
  title: string;
  description: string;
  href?: string;
  disabled?: boolean;
};

export function ProcessCard({
  icon,
  title,
  description,
  href,
  disabled = false,
}: ProcessCardProps) {
  return (
    <div
      className={`flex h-full flex-col justify-between rounded-card border p-6 transition-colors ${
        disabled
          ? "border-line/70 bg-white/50"
          : "border-line bg-surface shadow-soft"
      }`}
    >
      <div>
        <div className="flex items-center justify-between">
          <span className="text-3xl" aria-hidden="true">
            {icon}
          </span>
          {disabled && (
            <span className="rounded-full bg-ink/5 px-3 py-1 text-xs font-semibold text-muted">
              Yakında
            </span>
          )}
        </div>
        <h3
          className={`mt-4 font-display text-xl ${
            disabled ? "text-muted" : "text-ink"
          }`}
        >
          {title}
        </h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {description}
        </p>
      </div>

      <div className="mt-6">
        <Button
          href={href}
          disabled={disabled}
          variant={disabled ? "ghost" : "primary"}
          className="w-full"
        >
          {disabled ? "Yakında" : "Başla"}
        </Button>
      </div>
    </div>
  );
}
