const steps = ["Bilgiler", "Belgeler", "Kontrol", "Hesaplama", "İşlem Dosyası"];

export function StepProgress({ currentStep = 1 }: { currentStep?: number }) {
  return (
    <ol className="flex w-full items-start gap-1 sm:gap-2">
      {steps.map((label, i) => {
        const stepNumber = i + 1;
        const isDone = stepNumber < currentStep;
        const isActive = stepNumber === currentStep;

        return (
          <li key={label} className="flex flex-1 flex-col items-center gap-2">
            <div className="flex w-full items-center">
              <div
                className={`h-1.5 flex-1 rounded-full ${
                  i === 0 ? "opacity-0" : isDone || isActive ? "bg-petrol" : "bg-line"
                }`}
              />
              <span
                className={`mx-1.5 flex h-7 w-7 flex-none items-center justify-center rounded-full text-xs font-semibold ${
                  isDone
                    ? "bg-petrol text-white"
                    : isActive
                      ? "border-2 border-petrol text-petrol"
                      : "border border-line text-muted"
                }`}
              >
                {isDone ? "✓" : stepNumber}
              </span>
              <div
                className={`h-1.5 flex-1 rounded-full ${
                  i === steps.length - 1
                    ? "opacity-0"
                    : isDone
                      ? "bg-petrol"
                      : "bg-line"
                }`}
              />
            </div>
            <span
              className={`hidden text-center text-xs font-medium sm:block ${
                isActive ? "text-ink" : "text-muted"
              }`}
            >
              {label}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
